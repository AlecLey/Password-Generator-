"use strict";

/**
 * Register callback to respond to the form submit event
 */
const form = document.querySelector('#passwordGenerator');
form.addEventListener('submit', onPasswordFormSubmit);

/**
 * Register callback to respond to click on the clipboard button
 */
const clipboardButton = document.querySelector('#clipboardBtn');
clipboardButton.addEventListener('click', onClipboardBtnClick);

/**
 * Invoked when the user sumbits the password form (return or click submit).
 * This function should ...
 * 1. Extract the user supplied password options from the form
 * 2. Invoike the generatePassword() method
 * 3. Display the generated password 
 */
function onPasswordFormSubmit(event) {
    // Prevent the form from actually submitting to the server
    event.preventDefault();
    const txtPassword = document.getElementById('generatedPassword');
    const txtLength = document.getElementById('passwordLength');
    const boxUpperCase = document.getElementById('uppercaseOption');
    const boxNumbers = document.getElementById('numberOption');
    const boxSymbols = document.getElementById('symbolOption');

    // Get values for the password generation options (length, uppercase, etc.)
    const length = +txtLength.value;
    const hasUpper = boxUpperCase.checked;
    const hasNumber = boxNumbers.checked;
    const hasSymbol = boxSymbols.checked;

    // Generate the password with supplied options (invoke generatePassword)
    const password = generatePassword(length, hasUpper, hasNumber, hasSymbol);

    // Display the password in the text input (used for output in this case)
    txtPassword.value = password;
}

/**
 * Copy the generated to the system clipboard so that it can be pasted.
 * See https://www.w3schools.com/howto/howto_js_copy_clipboard.asp for API reference.
 */
function onClipboardBtnClick() {
    const textarea = document.createElement('textarea');
    const password = document.getElementById('generatedPassword').value;

    if(!password) {
        return
    }

    textarea.value = password;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    textarea.remove();
    alert('Password copied to clipboard!');
}
const method = {
    uppercase: getRandomUppercase,
    numbers: getRandomDigit,
    symbols: getRandomSymbol
};
/**
 * Returns a randomly generated password of size "length" as a string. Each of the supplied
 * options (uppercase, numbers, symbols) should have an equal chance of occuring in each character position.
 */
function generatePassword(length, uppercase, numbers, symbols) {
    let password = '';
    const count = uppercase + numbers + symbols;

    const array = [{uppercase}, {numbers}, {symbols}].filter(
        item => Object.values(item)[0]
    );
    
    if(count === 0)
        return '';

    for(let i = 0; i < length; i += count){
        array.forEach(type =>{
            const methodName = Object.keys(type)[0];
            password += method[methodName]();
        });
    }
    return password.slice(0, length);
}

const alphabet = "abcdefghijklmnopqrstuvwxyz";
// Returns a single, random lowercase character a-z
function getRandomLowercase() {
    return alphabet[Math.floor(Math.random() * alphabet.length)]
}

// Returns a single, random uppercase letter A-Z
function getRandomUppercase() {
    return getRandomLowercase().toUpperCase()
}

// Returns a single, radom digit 0-9
function getRandomDigit() {
    return Math.floor(Math.random() * 10);
}

// Returns a single, random symbol from the following symbols ... !, #, $, %, &, ), (
function getRandomSymbol() {
    const symbols = '!#$%&()';
    return symbols[Math.floor(Math.random() * symbols.length)];
}
